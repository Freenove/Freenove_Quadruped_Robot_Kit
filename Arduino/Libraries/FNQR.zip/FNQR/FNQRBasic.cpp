﻿/*
 * File				Basic classes for Freenove Quadruped Robot
 * Author			Ethan Pan @ Freenove (support@freenove.com)
 * Date				2017/05/18
 * Copyright	Copyright © Freenove (http://www.freenove.com)
 * License		Creative Commons Attribution ShareAlike 3.0
 *						(http://creativecommons.org/licenses/by-sa/3.0/legalcode)
 * -----------------------------------------------------------------------------------------------*/

#if defined(__AVR_ATmega2560__)

#include "FNQRBasic.h"

Point::Point() {}

Point::Point(float x, float y, float z)
{
	this->x = x;
	this->y = y;
	this->z = z;
}

float Point::GetDistance(Point point1, Point point2)
{
	return sqrt(pow(point1.x - point2.x, 2) + pow(point1.y - point2.y, 2) + pow(point1.z - point2.z, 2));
}

RobotLegsPoints::RobotLegsPoints() {}

RobotLegsPoints::RobotLegsPoints(Point leg1, Point leg2, Point leg3, Point leg4)
{
	this->leg1 = leg1;
	this->leg2 = leg2;
	this->leg3 = leg3;
	this->leg4 = leg4;
}

RobotJoint::RobotJoint() {}

void RobotJoint::Set(int servoPin, float jointZero, bool jointDir, float jointMinAngle, float jointMaxAngle, int offsetAddress)
{
	this->servoPin = servoPin;
	this->jointZero = jointZero;
	this->jointDir = jointDir;
	this->offsetAddress = offsetAddress;
	this->jointMinAngle = jointMinAngle;
	this->jointMaxAngle = jointMaxAngle;

	int offsetInt = EEPROM.read(offsetAddress) * 256 + EEPROM.read(offsetAddress + 1);
	offsetInt = offsetInt / 2 * ((offsetInt % 2) ? 1 : -1);
	float offset = offsetInt * 0.01;
	this->offset = offset;
}

void RobotJoint::SetOffset(float offset)
{
	int offsetInt = offset * 100;
	offsetInt = abs(offsetInt) * 2 + ((offset > 0) ? 1 : 0);

	if (offsetInt < 0 || offsetInt > 65535)
		return;

	EEPROM.write(offsetAddress, offsetInt / 256);
	EEPROM.write(offsetAddress + 1, offsetInt % 256);
	this->offset = offset;
}

void RobotJoint::SetOffsetEnableState(bool state)
{
	isOffsetEnable = state;
}

void RobotJoint::RotateToDirectly(float jointAngle)
{
	float servoAngle;

	if (isOffsetEnable)
		servoAngle = jointZero + (jointDir ? 1 : -1) * (jointAngle + offset);
	else
		servoAngle = jointZero + (jointDir ? 1 : -1) * jointAngle;

	while (servoAngle > 360)
		servoAngle -= 360;
	while (servoAngle < 0)
		servoAngle += 360;
	if (servoAngle > 180)
		return;

	if (isFirstRotate)
	{
		isFirstRotate = false;
		servo.attach(servoPin);
		servo.write(servoAngle);
		delay(firstRotateDelay);
	}
	else
	{
		servo.write(servoAngle);
	}

	jointAngleNow = jointAngle;
	servoAngleNow = servoAngle;
}

float RobotJoint::GetJointAngle(float servoAngle)
{
	return (jointDir ? 1 : -1) * (servoAngle - jointZero);
}

bool RobotJoint::CheckJointAngle(float jointAngle)
{
	while (jointAngle > 360)
		jointAngle -= 360;
	while (jointAngle < 0)
		jointAngle += 360;

	if (jointAngle >= jointMinAngle && jointAngle <= jointMaxAngle)
		return true;
	else
		return false;
}

RobotLeg::RobotLeg() {}

void RobotLeg::Set(float xOrigin, float yOrigin)
{
	this->xOrigin = xOrigin;
	this->yOrigin = yOrigin;
}

void RobotLeg::SetOffsetEnableState(bool state)
{
	jointA.SetOffsetEnableState(state);
	jointB.SetOffsetEnableState(state);
	jointC.SetOffsetEnableState(state);
}

void RobotLeg::MoveToDirectly(Point point)
{
	if (!CheckPoint(point))
		return;

	float alpha, beta, gamma;
	CalculateAngle(point, alpha, beta, gamma);
	RotateToDirectly(alpha, beta, gamma);
}

void RobotLeg::MoveToDirectlyRelatively(Point point)
{
	point = Point(pointGoal.x + point.x, pointGoal.y + point.y, pointGoal.z + point.z);
	MoveToDirectly(point);
}

void RobotLeg::RotateToDirectly(float alpha, float beta, float gamma)
{
	jointC.RotateToDirectly(gamma);
	jointB.RotateToDirectly(beta);
	jointA.RotateToDirectly(alpha);

	Point point;
	CalculatePoint(alpha, beta, gamma, point);

	if (isFirstMove)
	{
		isFirstMove = false;
		pointGoal = point;
	}

	pointNow = point;
}

void RobotLeg::ServosRotateTo(float degreeA, float degreeB, float degreeC)
{
	float alpha = jointA.GetJointAngle(degreeA);
	float beta = jointB.GetJointAngle(degreeB);
	float gamma = jointC.GetJointAngle(degreeC);

	Point point;
	CalculatePoint(alpha, beta, gamma, point);

	MoveTo(point);
}

void RobotLeg::CalculatePoint(float alpha, float beta, float gamma, volatile float &x, volatile float &y, volatile float &z)
{
	// transform angle to radian
	alpha = alpha * PI / 180;
	beta = beta  * PI / 180;
	gamma = gamma * PI / 180;
	// calculate u-v coordinate
	float u, v;
	u = RobotShape::d + RobotShape::e * sin(beta) + RobotShape::f * sin(gamma - beta);
	v = RobotShape::c + RobotShape::e * cos(beta) - RobotShape::f * cos(gamma - beta);
	// calculate x-y-z coordinate
	x = xOrigin + u * cos(alpha);
	y = yOrigin + u * sin(alpha);
	z = v;
}

void RobotLeg::CalculatePoint(float alpha, float beta, float gamma, Point &point)
{
	CalculatePoint(alpha, beta, gamma, point.x, point.y, point.z);
}

void RobotLeg::CalculateAngle(float x, float y, float z, float &alpha, float &beta, float &gamma)
{
	// calculate u-v angle
	float u, v;
	u = sqrt(pow(x - xOrigin, 2) + pow(y - yOrigin, 2));
	v = z;
	beta = PI / 2 - acos((pow(RobotShape::e, 2) + (pow(u - RobotShape::d, 2) + pow(v - RobotShape::c, 2)) - pow(RobotShape::f, 2)) / (2 * RobotShape::e * sqrt(pow(u - RobotShape::d, 2) + pow(v - RobotShape::c, 2)))) - atan2(v - RobotShape::c, u - RobotShape::d);
	gamma = acos((pow(RobotShape::e, 2) + pow(RobotShape::f, 2) - (pow(u - RobotShape::d, 2) + pow(v - RobotShape::c, 2))) / (2 * RobotShape::e * RobotShape::f));
	// calculate x-y-z angle
	alpha = atan2(y - yOrigin, x - xOrigin);
	if (xOrigin < 0 && yOrigin < 0)
		alpha = alpha + PI;
	if (xOrigin < 0 && yOrigin < 0)
		alpha = alpha + PI;
	// transform radian to angle
	alpha = alpha * 180 / PI;
	beta = beta * 180 / PI;
	gamma = gamma * 180 / PI;
}

void RobotLeg::CalculateAngle(Point point, float &alpha, float &beta, float &gamma)
{
	CalculateAngle(point.x, point.y, point.z, alpha, beta, gamma);
}

bool RobotLeg::CheckPoint(Point point)
{
	float alpha, beta, gamma;
	CalculateAngle(point, alpha, beta, gamma);
	if (!CheckAngle(alpha, beta, gamma))
		return false;

	Point pointNew;
	CalculatePoint(alpha, beta, gamma, pointNew);
	if(Point::GetDistance(point, pointNew) > 1)
		return false;

	return true;
}

bool RobotLeg::CheckAngle(float alpha, float beta, float gamma)
{
	if (jointA.CheckJointAngle(alpha) && jointB.CheckJointAngle(beta) && jointC.CheckJointAngle(gamma))
		return true;
	else
		return false;
}

void RobotLeg::MoveTo(Point point)
{
	if (!CheckPoint(point))
		return;

	pointGoal = point;
	isBusy = true;
}

void RobotLeg::MoveToRelatively(Point point)
{
	point = Point(pointGoal.x + point.x, pointGoal.y + point.y, pointGoal.z + point.z);
	MoveTo(point);
}

void RobotLeg::WaitUntilFree()
{
	while (isBusy);
}

Robot::Robot() {}

void Robot::Start()
{
	leg1.Set(-RobotShape::a, RobotShape::a);
	leg2.Set(-RobotShape::a, -RobotShape::a);
	leg3.Set(RobotShape::a, RobotShape::a);
	leg4.Set(RobotShape::a, -RobotShape::a);

	leg1.jointA.Set(22, -45, true, 90, 180, EepromAddresses::servo22);
	leg1.jointB.Set(23, 0, true, 0, 180, EepromAddresses::servo23);
	leg1.jointC.Set(24, 0, true, 0, 180, EepromAddresses::servo24);
	leg2.jointA.Set(25, -135, true, 180, 270, EepromAddresses::servo25);
	leg2.jointB.Set(26, 180, false, 0, 180, EepromAddresses::servo26);
	leg2.jointC.Set(27, 180, false, 0, 180, EepromAddresses::servo27);
	leg3.jointA.Set(39, 45, true, 0, 90, EepromAddresses::servo39);
	leg3.jointB.Set(38, 180, false, 0, 180, EepromAddresses::servo38);
	leg3.jointC.Set(37, 180, false, 0, 180, EepromAddresses::servo37);
	leg4.jointA.Set(36, 135, true, 270, 360, EepromAddresses::servo36);
	leg4.jointB.Set(35, 0, true, 0, 180, EepromAddresses::servo35);
	leg4.jointC.Set(34, 0, true, 0, 180, EepromAddresses::servo34);

	MoveToDirectly(bootPoints);
}

void Robot::SetOffsetEnableState(bool state)
{
	leg1.SetOffsetEnableState(state);
	leg2.SetOffsetEnableState(state);
	leg3.SetOffsetEnableState(state);
	leg4.SetOffsetEnableState(state);
}

void Robot::InstallState()
{
	state = State::Install;
	SetOffsetEnableState(false);
	SetSpeed(RobotLeg::defaultStepDistance);
	leg1.ServosRotateTo(90, 90, 90);
	leg2.ServosRotateTo(90, 90, 90);
	leg3.ServosRotateTo(90, 90, 90);
	leg4.ServosRotateTo(90, 90, 90);
	WaitUntilFree();
}

void Robot::BootState()
{
	SetOffsetEnableState(true);
	SetSpeed(RobotLeg::defaultStepDistance);
	MoveTo(bootPoints);
	WaitUntilFree();
	state = State::Boot;
}

void Robot::CalibrateState()
{
	state = State::Calibrate;
	SetOffsetEnableState(false);
	SetSpeed(RobotLeg::defaultStepDistance);
	MoveTo(calibrateStatePoints);
	WaitUntilFree();
}

void Robot::CalibrateServos()
{
	if (state != State::Calibrate)
		return;
	CalibrateLeg(leg1, calibratePoints.leg1);
	CalibrateLeg(leg2, calibratePoints.leg2);
	CalibrateLeg(leg3, calibratePoints.leg3);
	CalibrateLeg(leg4, calibratePoints.leg4);
	SetOffsetEnableState(true);
}

void Robot::CalibrateVerify()
{
	state = State::Calibrate;
	SetSpeed(RobotLeg::defaultStepDistance);
	MoveTo(calibrateStatePoints);
	WaitUntilFree();
	SetOffsetEnableState(true);
	MoveTo(calibratePoints);
	WaitUntilFree();
}

void Robot::CalibrateLeg(RobotLeg &leg, Point calibratePoint)
{
	float alpha, beta, gamma;
	leg.CalculateAngle(calibratePoint, alpha, beta, gamma);
	leg.jointA.SetOffset(leg.jointA.jointAngleNow - alpha);
	leg.jointB.SetOffset(leg.jointB.jointAngleNow - beta);
	leg.jointC.SetOffset(leg.jointC.jointAngleNow - gamma);
}

void Robot::MoveToDirectly(RobotLegsPoints points)
{
	leg1.MoveToDirectly(points.leg1);
	leg2.MoveToDirectly(points.leg2);
	leg3.MoveToDirectly(points.leg3);
	leg4.MoveToDirectly(points.leg4);
}

void Robot::MoveTo(RobotLegsPoints points)
{
	leg1.MoveTo(points.leg1);
	leg2.MoveTo(points.leg2);
	leg3.MoveTo(points.leg3);
	leg4.MoveTo(points.leg4);
}

void Robot::MoveTo(RobotLegsPoints points, float speed)
{
	SetSpeed(speed);
	MoveTo(points);
}

void Robot::MoveToRelatively(Point point)
{
	leg1.MoveToRelatively(point);
	leg2.MoveToRelatively(point);
	leg3.MoveToRelatively(point);
	leg4.MoveToRelatively(point);
}

void Robot::MoveToRelatively(Point point, float speed)
{
	SetSpeed(speed);
	MoveToRelatively(point);
}

void Robot::UpdateAction()
{
	UpdateLegAction(leg1);
	UpdateLegAction(leg2);
	UpdateLegAction(leg3);
	UpdateLegAction(leg4);
}

void Robot::UpdateLegAction(RobotLeg &leg)
{
	float distance = Point::GetDistance(leg.pointNow, leg.pointGoal);
	float xDistance = leg.pointGoal.x - leg.pointNow.x;
	float yDistance = leg.pointGoal.y - leg.pointNow.y;
	float zDistance = leg.pointGoal.z - leg.pointNow.z;
	float xStep = xDistance / distance * leg.stepDistance;
	float yStep = yDistance / distance * leg.stepDistance;
	float zStep = zDistance / distance * leg.stepDistance;
	Point pointGoal = Point(leg.pointNow.x + xStep, leg.pointNow.y + yStep, leg.pointNow.z + zStep);

	if (distance >= leg.stepDistance)
	{
		leg.isBusy = true;
		leg.MoveToDirectly(pointGoal);
	}
	else if (distance >= minDistance)
	{
		leg.isBusy = true;
		leg.MoveToDirectly(leg.pointGoal);
	}
	else
	{
		leg.isBusy = false;
	}
}

void Robot::WaitUntilFree()
{
	while (leg1.isBusy || leg2.isBusy || leg3.isBusy || leg4.isBusy);
}

void Robot::SetSpeed(float speed)
{
	leg1.stepDistance = speed;
	leg2.stepDistance = speed;
	leg3.stepDistance = speed;
	leg4.stepDistance = speed;
}

void Robot::SetSpeed(float speed1, float speed2, float speed3, float speed4)
{
	leg1.stepDistance = speed1;
	leg2.stepDistance = speed2;
	leg3.stepDistance = speed3;
	leg4.stepDistance = speed4;
}

void Robot::GetPointsNow(RobotLegsPoints & points)
{
	points.leg1 = leg1.pointNow;
	points.leg2 = leg2.pointNow;
	points.leg3 = leg3.pointNow;
	points.leg4 = leg4.pointNow;
}

RobotAction::RobotAction() {}

void RobotAction::Start()
{
	robot.Start();
}

void RobotAction::GetRotatePoints(RobotLegsPoints & points, float x, float y, float z, float angle)
{
	float vectorLength = sqrt(pow(x, 2) + pow(y, 2) + pow(z, 2));
	if (vectorLength == 0)
	{
		x = 0;
		y = 0;
		z = 1;
	}
	else
	{
		x = x / vectorLength;
		y = y / vectorLength;
		z = z / vectorLength;
	}

	GetRotatePoint(points.leg1, x, y, z, angle);
	GetRotatePoint(points.leg2, x, y, z, angle);
	GetRotatePoint(points.leg3, x, y, z, angle);
	GetRotatePoint(points.leg4, x, y, z, angle);
}

void RobotAction::GetRotatePoint(Point & point, float x, float y, float z, float angle)
{
	float old_x = point.x;
	float old_y = point.y;
	float old_z = point.z;

	angle = angle * PI / 180;
	float c = cos(angle);
	float s = sin(angle);

	point.x = (x * x * (1 - c) + c) * old_x + (x * y * (1 - c) - z * s) * old_y + (x * z * (1 - c) + y * s) * old_z;
	point.y = (y * x * (1 - c) + z * s) * old_x + (y * y * (1 - c) + c) * old_y + (y * z * (1 - c) - x * s) * old_z;
	point.z = (x * z * (1 - c) - y * s) * old_x + (y * z * (1 - c) + x * s) * old_y + (z * z * (1 - c) + c) * old_z;
}

void RobotAction::LegStepTo(RobotLeg & leg, Point point, float speed)
{
	leg.stepDistance = speed;
	leg.MoveToRelatively(Point(0, 0, cAz));
	leg.WaitUntilFree();
	leg.MoveTo(Point(point.x, point.y, leg.pointNow.z));
	leg.WaitUntilFree();
	leg.MoveToRelatively(Point(0, 0, -cAz));
	leg.WaitUntilFree();
}

void RobotAction::LegStepToRelatively(RobotLeg &leg, Point point, float speed)
{
	leg.stepDistance = speed;
	leg.MoveToRelatively(Point(0, 0, cAz));
	leg.WaitUntilFree();
	leg.MoveToRelatively(Point(point.x, point.y, 0));
	leg.WaitUntilFree();
	leg.MoveToRelatively(Point(0, 0, -cAz));
	leg.WaitUntilFree();
}

void RobotAction::LegsMoveTo(RobotLegsPoints points)
{
	robot.MoveTo(points);
	robot.WaitUntilFree();
}

void RobotAction::LegsMoveTo(RobotLegsPoints points, float speed)
{
	robot.SetSpeed(speed);
	robot.MoveTo(points);
	robot.WaitUntilFree();
}

void RobotAction::LegsMoveToRelatively(Point point, float speed)
{
	robot.SetSpeed(speed);
	robot.MoveToRelatively(point);
	robot.WaitUntilFree();
}

void RobotAction::FirstStepForward()
{
	if (feetState != FeetState::FeetSquare)
		return;
	if (mode != Mode::Active)
		ActiveMode();
	LegsMoveToRelatively(Point(cAx, 0, 0), speed2);
	LegStepToRelatively(robot.leg3, Point(0, 4 * cAy, 0), speed1);
	LegsMoveToRelatively(Point(-cAx, -2 * cAy, 0), speed2);
	LegStepToRelatively(robot.leg2, Point(0, 4 * cAy, 0), speed1);
	////
	feetState = FeetState::Feet34Long;
}

void RobotAction::FirstStepBackward()
{
	if (feetState != FeetState::FeetSquare)
		return;
	if (mode != Mode::Active)
		ActiveMode();
	LegsMoveToRelatively(Point(-cAx, 0, 0), speed2);
	LegStepToRelatively(robot.leg2, Point(0, -4 * cAy, 0), speed1);
	LegsMoveToRelatively(Point(cAx, 2 * cAy, 0), speed2);
	LegStepToRelatively(robot.leg3, Point(0, -4 * cAy, 0), speed1);
	////
	feetState = FeetState::Feet12Long;
}

void RobotAction::FeetSquareState()
{
	ActionState();
	if (mode != Mode::Active)
		ActiveMode();
	if (feetState == FeetState::FeetSquare)
		return;
	if (feetState == FeetState::Feet34Long)
	{
		LegsMoveToRelatively(Point(-fAl, fAl, 0), speed2);
		LegStepToRelatively(robot.leg1, Point(0, 2 * fAl, 0), speed1);
		LegsMoveToRelatively(Point(0, -2 * fAl, 0), speed2);
		LegStepToRelatively(robot.leg2, Point(0, -2 * fAl, 0), speed1);
		LegsMoveToRelatively(Point(2 * fAl, 0, 0), speed2);
		LegStepToRelatively(robot.leg4, Point(0, 2 * fAl, 0), speed1);
		LegsMoveToRelatively(Point(0, 2 * fAl, 0), speed2);
		LegStepToRelatively(robot.leg3, Point(0, -2 * fAl, 0), speed1);
		LegsMoveToRelatively(Point(-fAl, -fAl, 0), speed2);
	}
	else if (feetState == FeetState::Feet12Long)
	{
		LegsMoveToRelatively(Point(fAl, fAl, 0), speed2);
		LegStepToRelatively(robot.leg3, Point(0, 2 * fAl, 0), speed1);
		LegsMoveToRelatively(Point(0, -2 * fAl, 0), speed2);
		LegStepToRelatively(robot.leg4, Point(0, -2 * fAl, 0), speed1);
		LegsMoveToRelatively(Point(-2 * fAl, 0, 0), speed2);
		LegStepToRelatively(robot.leg2, Point(0, 2 * fAl, 0), speed1);
		LegsMoveToRelatively(Point(0, 2 * fAl, 0), speed2);
		LegStepToRelatively(robot.leg1, Point(0, -2 * fAl, 0), speed1);
		LegsMoveToRelatively(Point(fAl, -fAl, 0), speed2);
	}
	else if (feetState == FeetState::FeetMove)
	{
		MoveBody(0, 0, 0);
	}
	else if (feetState == FeetState::FeetRotate)
	{
		RotateBody(0, 0, 0, 0);
	}
	feetState = FeetState::FeetSquare;
}

void RobotAction::ActionState()
{
	if (robot.state != Robot::State::Action)
	{
		robot.BootState();
		robot.state = Robot::State::Action;
		mode = Mode::Sleep;
		feetState = FeetState::FeetSquare;
	}
}

void RobotAction::CrawlForward()
{
	ActionState();
	if (feetState == FeetState::FeetMove || feetState == FeetState::FeetRotate)
		FeetSquareState();
	if (mode != Mode::Active)
		ActiveMode();
	if (feetState == FeetState::FeetSquare)
	{
		FirstStepForward();
		return;
	}
	if (feetState == FeetState::Feet34Long)
	{
		//
		LegsMoveToRelatively(Point(0, -0.5 * cAy, 0), speed2);
		//
		robot.leg1.stepDistance = speed1;

		robot.leg1.MoveToRelatively(Point(0, 0, cAz));
		robot.leg2.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg3.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg4.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg1.WaitUntilFree();

		robot.leg1.MoveToRelatively(Point(0, 7 * cAy, 0));
		robot.leg1.WaitUntilFree();

		robot.leg1.MoveToRelatively(Point(0, 0, -cAz));
		robot.WaitUntilFree();
		//
		LegsMoveToRelatively(Point(0, -cAy, 0), speed2);
		//
		robot.leg4.stepDistance = speed1;

		robot.leg1.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg2.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg3.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg4.MoveToRelatively(Point(0, 0, cAz));
		robot.leg4.WaitUntilFree();

		robot.leg4.MoveToRelatively(Point(0, 7 * cAy, 0));
		robot.leg4.WaitUntilFree();

		robot.leg4.MoveToRelatively(Point(0, 0, -cAz));
		robot.WaitUntilFree();
		//
		LegsMoveToRelatively(Point(0, -0.5 * cAy, 0), speed2);
		////
		feetState = FeetState::Feet12Long;
	}
	else
	{
		//
		LegsMoveToRelatively(Point(0, -0.5 * cAy, 0), speed2);
		//
		robot.leg3.stepDistance = speed1;

		robot.leg1.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg2.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg3.MoveToRelatively(Point(0, 0, cAz));
		robot.leg4.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg3.WaitUntilFree();

		robot.leg3.MoveToRelatively(Point(0, 7 * cAy, 0));
		robot.leg3.WaitUntilFree();

		robot.leg3.MoveToRelatively(Point(0, 0, -cAz));
		robot.WaitUntilFree();
		//
		LegsMoveToRelatively(Point(0, -cAy, 0), speed2);
		//
		robot.leg2.stepDistance = speed1;

		robot.leg1.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg2.MoveToRelatively(Point(0, 0, cAz));
		robot.leg3.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg4.MoveToRelatively(Point(0, -cAy, 0));
		robot.leg2.WaitUntilFree();

		robot.leg2.MoveToRelatively(Point(0, 7 * cAy, 0));
		robot.leg2.WaitUntilFree();

		robot.leg2.MoveToRelatively(Point(0, 0, -cAz));
		robot.WaitUntilFree();
		//
		LegsMoveToRelatively(Point(0, -0.5 * cAy, 0), speed2);
		////
		feetState = FeetState::Feet34Long;
	}
}

void RobotAction::CrawlBackward()
{
	ActionState();
	if (feetState == FeetState::FeetMove || feetState == FeetState::FeetRotate)
		FeetSquareState();
	if (mode != Mode::Active)
		ActiveMode();
	if (feetState == FeetState::FeetSquare)
	{
		FirstStepBackward();
		return;
	}
	if (feetState == FeetState::Feet12Long)
	{
		//
		LegsMoveToRelatively(Point(0, 0.5 * cAy, 0), speed2);
		//
		robot.leg4.stepDistance = speed1;

		robot.leg1.MoveToRelatively(Point(0, cAy, 0));
		robot.leg2.MoveToRelatively(Point(0, cAy, 0));
		robot.leg3.MoveToRelatively(Point(0, cAy, 0));
		robot.leg4.MoveToRelatively(Point(0, 0, cAz));
		robot.leg4.WaitUntilFree();

		robot.leg4.MoveToRelatively(Point(0, -7 * cAy, 0));
		robot.leg4.WaitUntilFree();

		robot.leg4.MoveToRelatively(Point(0, 0, -cAz));
		robot.WaitUntilFree();
		//
		LegsMoveToRelatively(Point(0, cAy, 0), speed2);
		//
		robot.leg1.stepDistance = speed1;

		robot.leg1.MoveToRelatively(Point(0, 0, cAz));
		robot.leg2.MoveToRelatively(Point(0, cAy, 0));
		robot.leg3.MoveToRelatively(Point(0, cAy, 0));
		robot.leg4.MoveToRelatively(Point(0, cAy, 0));
		robot.leg1.WaitUntilFree();

		robot.leg1.MoveToRelatively(Point(0, -7 * cAy, 0));
		robot.leg1.WaitUntilFree();

		robot.leg1.MoveToRelatively(Point(0, 0, -cAz));
		robot.WaitUntilFree();
		//
		LegsMoveToRelatively(Point(0, 0.5 * cAy, 0), speed2);
		////
		feetState = FeetState::Feet34Long;
	}
	else
	{
		//
		LegsMoveToRelatively(Point(0, 0.5 * cAy, 0), speed2);
		//
		robot.leg2.stepDistance = speed1;

		robot.leg1.MoveToRelatively(Point(0, cAy, 0));
		robot.leg2.MoveToRelatively(Point(0, 0, cAz));
		robot.leg3.MoveToRelatively(Point(0, cAy, 0));
		robot.leg4.MoveToRelatively(Point(0, cAy, 0));
		robot.leg2.WaitUntilFree();

		robot.leg2.MoveToRelatively(Point(0, -7 * cAy, 0));
		robot.leg2.WaitUntilFree();

		robot.leg2.MoveToRelatively(Point(0, 0, -cAz));
		robot.WaitUntilFree();
		//
		LegsMoveToRelatively(Point(0, cAy, 0), speed2);
		//
		robot.leg3.stepDistance = speed1;

		robot.leg1.MoveToRelatively(Point(0, cAy, 0));
		robot.leg2.MoveToRelatively(Point(0, cAy, 0));
		robot.leg3.MoveToRelatively(Point(0, 0, cAz));
		robot.leg4.MoveToRelatively(Point(0, cAy, 0));
		robot.leg3.WaitUntilFree();

		robot.leg3.MoveToRelatively(Point(0, -7 * cAy, 0));
		robot.leg3.WaitUntilFree();

		robot.leg3.MoveToRelatively(Point(0, 0, -cAz));
		robot.WaitUntilFree();
		//
		LegsMoveToRelatively(Point(0, 0.5 * cAy, 0), speed2);
		////
		feetState = FeetState::Feet12Long;
	}
}

void RobotAction::Turn(float angle)
{
	ActionState();
	if (feetState == FeetState::FeetMove || feetState == FeetState::FeetRotate)
		FeetSquareState();
	if (mode != Mode::Active)
		ActiveMode();

	angle /= 4;

	RobotLegsPoints points;

	if (angle > 0)
	{
		if (feetState == FeetState::Feet34Long)
		{
			// body move away from leg2
			LegsMoveToRelatively(Point(-tAl, -tAl, 0), speed4);
			// leg 2 up
			LegMoveToRelatively(robot.leg2, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(tAl, tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(-tAl, -tAl, 0));
			// set leg 2 point
			points.leg2 = robot.bootPoints.leg2;
			GetTurnPoint(points.leg2, angle * 3);
			GetMovePoint(points.leg2, Point(-tAl, -tAl, robot.leg2.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed3, speed4, speed4);
			LegsMoveTo(points);
			// leg 2 down
			LegMoveToRelatively(robot.leg2, Point(0, 0, -cAz), speed3);

			// body move away from leg4
			LegsMoveToRelatively(Point(2 * tAl, 0, 0), speed4);
			// leg 4 up
			LegMoveToRelatively(robot.leg4, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(-tAl, tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(tAl, -tAl, 0));
			// set leg 4 point
			points.leg4 = robot.bootPoints.leg4;
			GetTurnPoint(points.leg4, angle * 2);
			GetMovePoint(points.leg4, Point(tAl, -tAl, robot.leg4.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed4, speed4, speed3);
			LegsMoveTo(points);
			// leg 4 down
			LegMoveToRelatively(robot.leg4, Point(0, 0, -cAz), speed3);

			// body move away from leg3
			LegsMoveToRelatively(Point(0, 2 * tAl, 0), speed4);
			// leg 3 up
			LegMoveToRelatively(robot.leg3, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(-tAl, -tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(tAl, tAl, 0));
			// set leg 3 point
			points.leg3 = robot.bootPoints.leg3;
			GetTurnPoint(points.leg3, angle * 1);
			GetMovePoint(points.leg3, Point(tAl, tAl, robot.leg3.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed4, speed3, speed4);
			LegsMoveTo(points);
			// leg 3 down
			LegMoveToRelatively(robot.leg3, Point(0, 0, -cAz), speed3);

			// body move away from leg1
			LegsMoveToRelatively(Point(-2 * tAl, 0, 0), speed4);
			// leg 1 up
			LegMoveToRelatively(robot.leg1, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(tAl, -tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(-tAl, tAl, 0));
			// set leg 1 point
			points.leg1 = robot.bootPoints.leg1;
			GetTurnPoint(points.leg1, angle * 0);
			GetMovePoint(points.leg1, Point(-tAl, tAl, robot.leg1.pointNow.z));
			// body move
			robot.SetSpeed(speed3, speed4, speed4, speed4);
			LegsMoveTo(points);
			// leg 1 down
			LegMoveToRelatively(robot.leg1, Point(0, 0, -cAz), speed3);

			// body move to center
			LegsMoveToRelatively(Point(tAl, -tAl, 0), speed4);
		}
		else
		{
			// body move away from leg3
			LegsMoveToRelatively(Point(tAl, tAl, 0), speed4);
			// leg 3 up
			LegMoveToRelatively(robot.leg3, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(-tAl, -tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(tAl, tAl, 0));
			// set leg 3 point
			points.leg3 = robot.bootPoints.leg3;
			GetTurnPoint(points.leg3, angle * 3);
			GetMovePoint(points.leg3, Point(tAl, tAl, robot.leg3.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed4, speed3, speed4);
			LegsMoveTo(points);
			// leg 3 down
			LegMoveToRelatively(robot.leg3, Point(0, 0, -cAz), speed3);

			// body move away from leg1
			LegsMoveToRelatively(Point(-2 * tAl, 0, 0), speed4);
			// leg 1 up
			LegMoveToRelatively(robot.leg1, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(tAl, -tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(-tAl, tAl, 0));
			// set leg 1 point
			points.leg1 = robot.bootPoints.leg1;
			GetTurnPoint(points.leg1, angle * 2);
			GetMovePoint(points.leg1, Point(-tAl, tAl, robot.leg1.pointNow.z));
			// body move
			robot.SetSpeed(speed3, speed4, speed4, speed4);
			LegsMoveTo(points);
			// leg 1 down
			LegMoveToRelatively(robot.leg1, Point(0, 0, -cAz), speed3);

			// body move away from leg2
			LegsMoveToRelatively(Point(0, -2 * tAl, 0), speed4);
			// leg 2 up
			LegMoveToRelatively(robot.leg2, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(tAl, tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(-tAl, -tAl, 0));
			// set leg 2 point
			points.leg2 = robot.bootPoints.leg2;
			GetTurnPoint(points.leg2, angle * 1);
			GetMovePoint(points.leg2, Point(-tAl, -tAl, robot.leg2.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed3, speed4, speed4);
			LegsMoveTo(points);
			// leg 2 down
			LegMoveToRelatively(robot.leg2, Point(0, 0, -cAz), speed3);

			// body move away from leg4
			LegsMoveToRelatively(Point(2 * tAl, 0, 0), speed4);
			// leg 4 up
			LegMoveToRelatively(robot.leg4, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(-tAl, tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(tAl, -tAl, 0));
			// set leg 4 point
			points.leg4 = robot.bootPoints.leg4;
			GetTurnPoint(points.leg4, angle * 0);
			GetMovePoint(points.leg4, Point(tAl, -tAl, robot.leg4.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed4, speed4, speed3);
			LegsMoveTo(points);
			// leg 4 down
			LegMoveToRelatively(robot.leg4, Point(0, 0, -cAz), speed3);

			// body move to center
			LegsMoveToRelatively(Point(-tAl, tAl, 0), speed4);
		}
	}
	else
	{
		if (feetState == FeetState::Feet12Long)
		{
			// body move away from leg4
			LegsMoveToRelatively(Point(tAl, -tAl, 0), speed4);
			// leg 4 up
			LegMoveToRelatively(robot.leg4, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(-tAl, tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(tAl, -tAl, 0));
			// set leg 4 point
			points.leg4 = robot.bootPoints.leg4;
			GetTurnPoint(points.leg4, angle * 3);
			GetMovePoint(points.leg4, Point(tAl, -tAl, robot.leg4.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed4, speed4, speed3);
			LegsMoveTo(points);
			// leg 4 down
			LegMoveToRelatively(robot.leg4, Point(0, 0, -cAz), speed3);

			// body move away from leg2
			LegsMoveToRelatively(Point(-2 * tAl, 0, 0), speed4);
			// leg 2 up
			LegMoveToRelatively(robot.leg2, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(tAl, tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(-tAl, -tAl, 0));
			// set leg 2 point
			points.leg2 = robot.bootPoints.leg2;
			GetTurnPoint(points.leg2, angle * 2);
			GetMovePoint(points.leg2, Point(-tAl, -tAl, robot.leg2.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed3, speed4, speed4);
			LegsMoveTo(points);
			// leg 2 down
			LegMoveToRelatively(robot.leg2, Point(0, 0, -cAz), speed3);

			// body move away from leg1
			LegsMoveToRelatively(Point(0, 2 * tAl, 0), speed4);
			// leg 1 up
			LegMoveToRelatively(robot.leg1, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(tAl, -tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(-tAl, tAl, 0));
			// set leg 1 point
			points.leg1 = robot.bootPoints.leg1;
			GetTurnPoint(points.leg1, angle * 1);
			GetMovePoint(points.leg1, Point(-tAl, tAl, robot.leg1.pointNow.z));
			// body move
			robot.SetSpeed(speed3, speed4, speed4, speed4);
			LegsMoveTo(points);
			// leg 1 down
			LegMoveToRelatively(robot.leg1, Point(0, 0, -cAz), speed3);

			// body move away from leg3
			LegsMoveToRelatively(Point(2 * tAl, 0, 0), speed4);
			// leg 3 up
			LegMoveToRelatively(robot.leg3, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(-tAl, -tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(tAl, tAl, 0));
			// set leg 3 point
			points.leg3 = robot.bootPoints.leg3;
			GetTurnPoint(points.leg3, angle * 0);
			GetMovePoint(points.leg3, Point(tAl, tAl, robot.leg3.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed4, speed3, speed4);
			LegsMoveTo(points);
			// leg 3 down
			LegMoveToRelatively(robot.leg3, Point(0, 0, -cAz), speed3);

			// body move to center
			LegsMoveToRelatively(Point(-tAl, -tAl, 0), speed4);
		}
		else
		{
			// body move away from leg1
			LegsMoveToRelatively(Point(-tAl, tAl, 0), speed4);
			// leg 1 up
			LegMoveToRelatively(robot.leg1, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(tAl, -tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(-tAl, tAl, 0));
			// set leg 1 point
			points.leg1 = robot.bootPoints.leg1;
			GetTurnPoint(points.leg1, angle * 3);
			GetMovePoint(points.leg1, Point(-tAl, tAl, robot.leg1.pointNow.z));
			// body move
			robot.SetSpeed(speed3, speed4, speed4, speed4);
			LegsMoveTo(points);
			// leg 1 down
			LegMoveToRelatively(robot.leg1, Point(0, 0, -cAz), speed3);

			// body move away from leg3
			LegsMoveToRelatively(Point(2 * tAl, 0, 0), speed4);
			// leg 3 up
			LegMoveToRelatively(robot.leg3, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(-tAl, -tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(tAl, tAl, 0));
			// set leg 3 point
			points.leg3 = robot.bootPoints.leg3;
			GetTurnPoint(points.leg3, angle * 2);
			GetMovePoint(points.leg3, Point(tAl, tAl, robot.leg3.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed4, speed3, speed4);
			LegsMoveTo(points);
			// leg 3 down
			LegMoveToRelatively(robot.leg3, Point(0, 0, -cAz), speed3);

			// body move away from leg4
			LegsMoveToRelatively(Point(0, -2 * tAl, 0), speed4);
			// leg 4 up
			LegMoveToRelatively(robot.leg4, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(-tAl, tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(tAl, -tAl, 0));
			// set leg 4 point
			points.leg4 = robot.bootPoints.leg4;
			GetTurnPoint(points.leg4, angle * 1);
			GetMovePoint(points.leg4, Point(tAl, -tAl, robot.leg4.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed4, speed4, speed3);
			LegsMoveTo(points);
			// leg 4 down
			LegMoveToRelatively(robot.leg4, Point(0, 0, -cAz), speed3);

			// body move away from leg2
			LegsMoveToRelatively(Point(-2 * tAl, 0, 0), speed4);
			// leg 2 up
			LegMoveToRelatively(robot.leg2, Point(0, 0, cAz), speed3);
			// set legs points
			robot.GetPointsNow(points);
			GetMovePoints(points, Point(tAl, tAl, 0));
			GetTurnPoints(points, -angle);
			GetMovePoints(points, Point(-tAl, -tAl, 0));
			// set leg 2 point
			points.leg2 = robot.bootPoints.leg2;
			GetTurnPoint(points.leg2, angle * 0);
			GetMovePoint(points.leg2, Point(-tAl, -tAl, robot.leg2.pointNow.z));
			// body move
			robot.SetSpeed(speed4, speed3, speed4, speed4);
			LegsMoveTo(points);
			// leg 2 down
			LegMoveToRelatively(robot.leg2, Point(0, 0, -cAz), speed3);

			// body move to center
			LegsMoveToRelatively(Point(tAl, tAl, 0), speed4);
		}
	}
	feetState = FeetState::FeetSquare;
}

void RobotAction::LegMoveToRelatively(RobotLeg & leg, Point point, float speed)
{
	leg.stepDistance = speed;
	leg.MoveToRelatively(point);
	leg.WaitUntilFree();
}

void RobotAction::GetTurnPoints(RobotLegsPoints & points, float angle)
{
	GetTurnPoint(points.leg1, angle);
	GetTurnPoint(points.leg2, angle);
	GetTurnPoint(points.leg3, angle);
	GetTurnPoint(points.leg4, angle);
}

void RobotAction::GetTurnPoint(Point & point, float angle)
{
	float radian = angle * PI / 180;
	float radius = sqrt(pow(point.x, 2) + pow(point.y, 2));

	float x = radius * cos(atan2(point.y, point.x) + radian);
	float y = radius * sin(atan2(point.y, point.x) + radian);

	point = Point(x, y, point.z);
}

void RobotAction::GetMovePoints(RobotLegsPoints & points, Point point)
{
	GetMovePoint(points.leg1, point);
	GetMovePoint(points.leg2, point);
	GetMovePoint(points.leg3, point);
	GetMovePoint(points.leg4, point);
}

void RobotAction::GetMovePoint(Point & point, Point direction)
{
	point = Point(point.x + direction.x, point.y + direction.y, point.z + direction.z);
}

void RobotAction::TurnLeft()
{
	Turn(-turnAngle);
}

void RobotAction::TurnRight()
{
	Turn(turnAngle);
}

void RobotAction::MoveBody(float x, float y, float z)
{
	ActionState();
	if (feetState != FeetState::FeetMove)
		FeetSquareState();

	x = constrain(x, -30, 30);
	y = constrain(y, -30, 30);
	z = constrain(z, -15, 45);

	RobotLegsPoints points = robot.bootPoints;
	points.leg1.x -= x;
	points.leg1.y -= y;
	points.leg1.z -= activeStateAz + z;
	points.leg2.x -= x;
	points.leg2.y -= y;
	points.leg2.z -= activeStateAz + z;
	points.leg3.x -= x;
	points.leg3.y -= y;
	points.leg3.z -= activeStateAz + z;
	points.leg4.x -= x;
	points.leg4.y -= y;
	points.leg4.z -= activeStateAz + z;
	LegsMoveTo(points, speedMoveBody);

	feetState = FeetState::FeetMove;
}

void RobotAction::RotateBody(float x, float y, float z, float angle)
{
	ActionState();
	if (feetState != FeetState::FeetRotate)
		FeetSquareState();

	angle = constrain(angle, -15, 15);

	RobotLegsPoints points = robot.bootPoints;
	points.leg1.z -= activeStateAz;
	points.leg2.z -= activeStateAz;
	points.leg3.z -= activeStateAz;
	points.leg4.z -= activeStateAz;
	GetRotatePoints(points, x, y, z, angle);
	LegsMoveTo(points, speedRotateBody);

	feetState = FeetState::FeetRotate;
}

void RobotAction::ActiveMode()
{
	ActionState();
	if (feetState == FeetState::FeetMove || feetState == FeetState::FeetRotate)
		FeetSquareState();
	if (mode == Mode::Active)
		return;
	robot.SetSpeed(speed2);
	robot.MoveToRelatively(Point(0, 0, -activeStateAz));
	robot.WaitUntilFree();
	mode = Mode::Active;
}

void RobotAction::SleepMode()
{
	ActionState();
	if (feetState == FeetState::FeetMove || feetState == FeetState::FeetRotate)
		FeetSquareState();
	if (mode == Mode::Sleep)
		return;
	robot.SetSpeed(speed2);
	robot.MoveToRelatively(Point(0, 0, activeStateAz));
	robot.WaitUntilFree();
	mode = Mode::Sleep;
}

void RobotAction::SwitchMode()
{
	ActionState();
	if (mode == Mode::Active)
		SleepMode();
	else
		ActiveMode();
}

#endif
