﻿/*
 * File				Communiction commands for Freenove Quadruped Robot
 * Author			Ethan Pan @ Freenove (support@freenove.com)
 * Date				2017/4/22
 * Copyright	Copyright © Freenove (http://www.freenove.com)
 * License		Creative Commons Attribution ShareAlike 3.0
 *						(http://creativecommons.org/licenses/by-sa/3.0/legalcode)
 * -----------------------------------------------------------------------------------------------*/

#pragma once

class Command
{
	// Format:  [transStart] [command] [data 0] [data 1] ... [data n] [transEnd]
	//          [x] is byte type and the range of [command] and [data x] is 0~127
	// Process: The requesting party send the command, then the responding party respond the command.
	//          The non blocking command will be responded immediately, and the blocking command will
	//          be responded commandStart immediately, then respond commandDone after completion.

public:
	// Transmission control bytes, range is 128 ~ 255
	static const byte transStart = 128;
	static const byte transEnd = 129;


	// Commands, range is 0 ~ 127
	// Some commands have proprietary response commands, others use commandStart and commandDone
	// The even commands is sent by the requesting party, and the odd commands is sent by the 
	// responding party.


	// Non blocking commands, range 0 ~ 63

	// Request echo, to confirm the device
	static const byte requestEcho = 0;						// [Command]
	// Respond echo
	static const byte echo = 1;										// [Command]

	// Request supply voltage
	static const byte requestSupplyVoltage = 10;	// [Command]
	// Respond supply voltage
	static const byte supplyVoltage = 11;					// [Command] [voltage * 100 / 128] [voltage * 100 % 128]

	//
	static const byte requestMoveLeg = 20;				// [Command] [leg] [64 + dx] [64 + dy] [64 + dz]
	static const byte requestCalibrate = 22;			// [Command]

	//
	static const byte requestChangeIO = 30;				// [Command] [IOindex] [1/0]

	//
	static const byte requestMoveBodyTo = 40;			// [Command] [64 + x] [64 + y] [64 + z]
	static const byte requestRotateBodyTo = 42;		// [Command] [64 + x] [64 + y]

	// Universal responded commands
	static const byte commandStart = 21;					// [Command]
	static const byte commandDone = 23;						// [Command]


	// Blocking commands, range 64 ~ 127

	//
	static const byte requestCrawlForward = 64;		// [Command]
	static const byte requestCrawlBackward = 66;	// [Command]
	static const byte requestTurnLeft = 68;				// [Command]
	static const byte requestTurnRight = 70;			// [Command]
	static const byte requestActiveMode = 72;			// [Command]
	static const byte requestSleepMode = 74;			// [Command]
	static const byte requestSwitchMode = 76;			// [Command]

	//
	static const byte requestInstallState = 80;		// [Command]
	static const byte requestCalibrateState = 82;	// [Command]
	static const byte requestBootState = 84;			// [Command]

	//
	static const byte requestCalibrateVerify = 90;// [Command]

	//
	static const byte requestMoveBody = 100;			// [Command] [64 + x] [64 + y] [64 + z]
	static const byte requestRotateBody = 102;		// [Command] [64 + x] [64 + y]
};
