﻿/*
 * File				Class for control Freenove Quadruped Robot
 * Author			Ethan Pan @ Freenove (support@freenove.com)
 * Date				2017/4/22
 * Copyright	Copyright © Freenove (http://www.freenove.com)
 * License		Creative Commons Attribution ShareAlike 3.0
 *						(http://creativecommons.org/licenses/by-sa/3.0/legalcode)
 * -----------------------------------------------------------------------------------------------*/

#if defined(__AVR_ATmega2560__)

#include "FNQR.h"

Robot::Robot() {}

void Robot::Start(bool commFunction)
{
	communication.Start(commFunction);
}

void Robot::Update()
{
	if (communication.commFunction)
		communication.UpdateCommand();
}

void Robot::ActiveMode()
{
	if (!communication.commFunction)
		communication.quadrupedRobotAction.ActiveMode();
}

void Robot::SleepMode()
{
	if (!communication.commFunction)
		communication.quadrupedRobotAction.SleepMode();
}

void Robot::SwitchMode()
{
	if (!communication.commFunction)
		communication.quadrupedRobotAction.SwitchMode();
}

void Robot::CrawlForward()
{
	if (!communication.commFunction)
		communication.quadrupedRobotAction.CrawlForward();
}

void Robot::CrawlBackward()
{
	if (!communication.commFunction)
		communication.quadrupedRobotAction.CrawlBackward();
}

void Robot::TurnLeft()
{
	if (!communication.commFunction)
		communication.quadrupedRobotAction.TurnLeft();
}

void Robot::TurnRight()
{
	if (!communication.commFunction)
		communication.quadrupedRobotAction.TurnRight();
}

void Robot::MoveBody(float x, float y, float z)
{
	if (!communication.commFunction)
		communication.quadrupedRobotAction.MoveBody(x, y, z);
}

void Robot::RotateBody(float x, float y, float z, float angle)
{
	if (!communication.commFunction)
		communication.quadrupedRobotAction.RotateBody(x, y, z, angle);
}

#endif
