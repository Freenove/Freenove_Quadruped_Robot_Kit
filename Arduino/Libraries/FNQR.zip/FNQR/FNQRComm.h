﻿/*
 * File				Communiction class for Freenove Quadruped Robot
 * Author			Ethan Pan @ Freenove (support@freenove.com)
 * Date				2017/4/22
 * Copyright	Copyright © Freenove (http://www.freenove.com)
 * License		Creative Commons Attribution ShareAlike 3.0
 *						(http://creativecommons.org/licenses/by-sa/3.0/legalcode)
 * -----------------------------------------------------------------------------------------------*/

#pragma once
#if defined(__AVR_ATmega2560__)

#include "FNQRBasic.h"
#include "FNQRCmd.h"

#include <SPI.h>
#include "RF24.h"

#include "ESP8266.h"

class Communication
{
public:
	Communication();
	void Start(bool commFunction = true);

	bool commFunction;

	void UpdateCommunication();
	void UpdateCommand();

	QuadrupedRobotAction quadrupedRobotAction;

private:
	volatile byte blockedCommand = 0;
	volatile byte dynamicCommand = 0;

	unsigned long lastBlockedCommandTime = 0;
	const unsigned long autoSleepOvertime = 10000;

	byte moveBodyParameters[3];
	byte rotateBodyParameters[2];

	void UpdateBlockedCommand();
	void UpdateDynamicCommand();
	void UpdateAutoSleep();

	const int stateLedPin = 13;
	bool stateLedState = LOW;

	void StartStateLed();
	void SetStateLed(bool state);
	void ReverseStateLed();

	const int supplyVoltagePin = A7;

	float GetSupplyVoltage();

	const int pins[8] = { 20,21,A0,A1,15,14,2,3 };

	void StartPins();

	static const int inDataSize = 32;
	static const int outDataSize = 32;

	byte serialInData[inDataSize];
	byte serialInDataCounter = 0;
	void StartSerial();
	void UpdateSerial();

	RF24 rf24 = RF24(9, 53);
	const byte rf24Address[6] = { 'F', 'N', 'K', '2', '7' };
	bool isRF24Available = false;
	byte rf24InData[inDataSize];
	byte rf24InDataCounter = 0;

	void StartRF24();
	void UpdateRF24();

	const String esp8266SSID = "Freenove Quadruped Robot";
	const String esp8266PWD = "Freenove";
	const unsigned long esp8266Port = 65535;
	ESP8266 esp8266 = ESP8266(Serial2, 115200);
	bool isESP8266Available = false;
	byte esp8266ClientID;
	byte esp8266InData[inDataSize];
	byte esp8266InDataCounter = 0;

	void StartESP8266();
	void UpdateESP8266();

	enum CommandSource { FromSerial, FromRF24, FromESP8266 };
	CommandSource commandSource;

	enum ExecuteState { ExecuteStart, ExecuteDone, ExecuteNone };
	ExecuteState commandState = ExecuteNone;

	void HandleCommand(byte data[], CommandSource commandSource);

	void CheckBlockedCommand();

	void SetRobotBootState(QuadrupedRobot::State state);
	QuadrupedRobot::State GetRobotBootState();

	unsigned long ledCounter = 0;
	const int ledBlinkCycle = 20;
	int ledState = 0;
	void UpdateStateLED();
};

void UpdateService();

#endif
