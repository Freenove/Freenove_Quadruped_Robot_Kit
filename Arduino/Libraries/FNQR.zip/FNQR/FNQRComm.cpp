﻿/*
 * File				Communiction class for Freenove Quadruped Robot
 * Author			Ethan Pan @ Freenove (support@freenove.com)
 * Date				2017/4/23
 * Copyright	Copyright © Freenove (http://www.freenove.com)
 * License		Creative Commons Attribution ShareAlike 3.0
 *						(http://creativecommons.org/licenses/by-sa/3.0/legalcode)
 * -----------------------------------------------------------------------------------------------*/

#if defined(__AVR_ATmega2560__)

#include "FNQRComm.h"

Communication* communication = NULL;

Communication::Communication() {}

void Communication::Start(bool commFunction)
{
	this->commFunction = commFunction;

	StartStateLed();

	quadrupedRobotAction.Start();

	communication = this;

	FlexiTimer2::set(20, UpdateService);
	FlexiTimer2::start();

	if (commFunction)
	{
		StartPins();
		StartSerial();
		StartRF24();
		StartESP8266();
	}

	if (communication)
	{
		QuadrupedRobot::State state = GetRobotBootState();

		if (state == QuadrupedRobot::State::Install)
			quadrupedRobotAction.quadrupedRobot.InstallState();
		else if (state == QuadrupedRobot::State::Calibrate)
			quadrupedRobotAction.quadrupedRobot.CalibrateState();
		else if (state == QuadrupedRobot::State::Boot)
			quadrupedRobotAction.quadrupedRobot.BootState();
	}
}

void Communication::StartStateLed()
{
	pinMode(stateLedPin, OUTPUT);
	digitalWrite(stateLedPin, LOW);
}

void Communication::SetStateLed(bool state)
{
	digitalWrite(stateLedPin, state);
}

void Communication::ReverseStateLed()
{
	stateLedState = !stateLedState;
	SetStateLed(stateLedState);
}

float Communication::GetSupplyVoltage()
{
	return analogRead(supplyVoltagePin) * 5.0 / 1024 * 2;
}

void Communication::StartPins()
{
	for (int i = 0; i < 8; i++)
	{
		pinMode(pins[i], OUTPUT);
		digitalWrite(pins[i], LOW);
	}
}

void Communication::StartSerial()
{
	Serial.begin(115200);
}

void Communication::UpdateSerial()
{
	while (Serial.available() > 0)
	{
		byte inByte = Serial.read();
		if (inByte == Command::transStart)
			serialInDataCounter = 0;
		serialInData[serialInDataCounter++] = inByte;
		if (inByte == Command::transEnd)
			break;
	}

	if (serialInData[0] == Command::transStart && serialInData[serialInDataCounter - 1] == Command::transEnd)
	{
		HandleCommand(serialInData, CommandSource::FromSerial);
		serialInDataCounter = 0;
	}
}

void Communication::StartRF24()
{
	isRF24Available = rf24.begin();
	if (!isRF24Available)
		return;
	rf24.setPALevel(RF24_PA_LOW);
	rf24.setDataRate(RF24_1MBPS);
	rf24.setRetries(0, 15);
	rf24.openWritingPipe(rf24Address);
	rf24.openReadingPipe(1, rf24Address);
	rf24.startListening();
}

void Communication::UpdateRF24()
{
	if (!isRF24Available)
		return;

	for (int index = 0; index < inDataSize; index++)
		rf24InData[index] = 0;

	if (rf24.available())
	{
		rf24.read(rf24InData, inDataSize);

		for (int index = 0; index < inDataSize; index++)
		{
			if (rf24InData[index] == Command::transStart)
			{
				if (rf24InData[index + 1] != Command::requestEcho)
					HandleCommand(rf24InData + index, CommandSource::FromRF24);
			}
		}
	}
}

void Communication::StartESP8266()
{
	if (esp8266.kick())
		if (esp8266.setOprToSoftAP())
			if (esp8266.setSoftAPParam(esp8266SSID, esp8266PWD))
				if (esp8266.enableMUX())
					if (esp8266.startTCPServer(esp8266Port))
						if (esp8266.setTCPServerTimeout(0))
						{
							isESP8266Available = true;
							return;
						}
	isESP8266Available = false;
}

void Communication::UpdateESP8266()
{
	if (!isESP8266Available)
		return;

	for (int index = 0; index < inDataSize; index++)
		esp8266InData[index] = 0;

	esp8266InDataCounter = esp8266.recv(&esp8266ClientID, esp8266InData, inDataSize, 2);

	if (esp8266InDataCounter > 0)
	{
		for (int index = 0; index < inDataSize; index++)
		{
			if (esp8266InData[index] == Command::transStart)
			{
				HandleCommand(esp8266InData + index, CommandSource::FromESP8266);
			}
		}
	}
}

void Communication::HandleCommand(byte inData[], CommandSource commandSource)
{
	if (blockedCommand != 0)
		return;

	this->commandSource = commandSource;

	byte outData[outDataSize];
	byte outDataCounter = 0;

	outData[outDataCounter++] = Command::transStart;

	if (inData[1] == Command::requestEcho)
	{
		outData[outDataCounter++] = Command::echo;
	}
	else if (inData[1] == Command::requestSupplyVoltage)
	{
		float supplyVoltage = GetSupplyVoltage();
		outData[outDataCounter++] = Command::supplyVoltage;
		outData[outDataCounter++] = (int)(supplyVoltage * 100) / 128;
		outData[outDataCounter++] = (int)(supplyVoltage * 100) % 128;
	}
	else if (inData[1] == Command::requestChangeIO)
	{
		digitalWrite(pins[inData[2]], inData[3]);
		outData[outDataCounter++] = Command::commandDone;
	}
	else if (inData[1] == Command::requestMoveLeg)
	{
		switch (inData[2]) {
		case 1:
			quadrupedRobotAction.quadrupedRobot.leg1.MoveToRelatively(Point(inData[3] - 64, inData[4] - 64, inData[5] - 64));
			break;
		case 2:
			quadrupedRobotAction.quadrupedRobot.leg2.MoveToRelatively(Point(inData[3] - 64, inData[4] - 64, inData[5] - 64));
			break;
		case 3:
			quadrupedRobotAction.quadrupedRobot.leg3.MoveToRelatively(Point(inData[3] - 64, inData[4] - 64, inData[5] - 64));
			break;
		case 4:
			quadrupedRobotAction.quadrupedRobot.leg4.MoveToRelatively(Point(inData[3] - 64, inData[4] - 64, inData[5] - 64));
			break;
		}
		outData[outDataCounter++] = Command::commandDone;
	}
	else if (inData[1] == Command::requestCalibrate)
	{
		quadrupedRobotAction.quadrupedRobot.CalibrateServos();
		outData[outDataCounter++] = Command::commandDone;
	}
	else if (inData[1] >= 64 && inData[1] <= 98)
	{
		blockedCommand = inData[1];
		outData[outDataCounter++] = Command::commandStart;
	}
	else if (inData[1] == Command::requestMoveBody)
	{
		blockedCommand = inData[1];
		moveBodyParameters[0] = inData[2];
		moveBodyParameters[1] = inData[3];
		moveBodyParameters[2] = inData[4];
		outData[outDataCounter++] = Command::commandStart;
	}
	else if (inData[1] == Command::requestRotateBody)
	{
		blockedCommand = inData[1];
		rotateBodyParameters[0] = inData[2];
		rotateBodyParameters[1] = inData[3];
		outData[outDataCounter++] = Command::commandStart;
	}
	else if (inData[1] == Command::requestMoveBodyTo)
	{
		dynamicCommand = inData[1];
		moveBodyParameters[0] = inData[2];
		moveBodyParameters[1] = inData[3];
		moveBodyParameters[2] = inData[4];
		outData[outDataCounter++] = Command::commandDone;
	}
	else if (inData[1] == Command::requestRotateBodyTo)
	{
		dynamicCommand = inData[1];
		rotateBodyParameters[0] = inData[2];
		rotateBodyParameters[1] = inData[3];
		outData[outDataCounter++] = Command::commandDone;
	}
	outData[outDataCounter++] = Command::transEnd;

	if (blockedCommand != 0)
		dynamicCommand = 0;

	if (commandSource == CommandSource::FromSerial)
		Serial.write(outData, outDataCounter);
	else if (commandSource == CommandSource::FromESP8266)
	{
		if (inData[1] != Command::requestMoveBodyTo && inData[1] != Command::requestRotateBodyTo)
			esp8266.send(esp8266ClientID, outData, outDataCounter);
	}
}

void Communication::UpdateCommunication()
{
	UpdateStateLED();

	if (commFunction)
	{
		UpdateSerial();
		UpdateRF24();
		UpdateESP8266();
		CheckBlockedCommand();
	}
}

void Communication::UpdateCommand()
{
	UpdateBlockedCommand();
	UpdateDynamicCommand();
	UpdateAutoSleep();
}

void Communication::UpdateStateLED()
{
	if (ledCounter / ledBlinkCycle < ledState)
	{
		if (ledCounter % ledBlinkCycle == 0)
			SetStateLed(HIGH);
		else if (ledCounter % ledBlinkCycle == ledBlinkCycle / 2)
			SetStateLed(LOW);
	}

	ledCounter++;

	if (ledCounter / ledBlinkCycle >= ledState + 3)
	{
		ledCounter = 0;
		if (quadrupedRobotAction.quadrupedRobot.state == QuadrupedRobot::State::Action)
			ledState = 1;
		else if (quadrupedRobotAction.quadrupedRobot.state == QuadrupedRobot::State::Boot)
			ledState = 1;
		else if (quadrupedRobotAction.quadrupedRobot.state == QuadrupedRobot::State::Calibrate)
			ledState = 2;
		else if (quadrupedRobotAction.quadrupedRobot.state == QuadrupedRobot::State::Install)
			ledState = 3;
	}
}

void Communication::UpdateBlockedCommand()
{
	byte blockedCommand = this->blockedCommand;
	if (blockedCommand == 0)
		return;

	lastBlockedCommandTime = millis();

	commandState = ExecuteState::ExecuteStart;

	if (blockedCommand == Command::requestCrawlForward)
	{
		quadrupedRobotAction.CrawlForward();
	}
	else if (blockedCommand == Command::requestCrawlBackward)
	{
		quadrupedRobotAction.CrawlBackward();
	}
	else if (blockedCommand == Command::requestTurnLeft)
	{
		quadrupedRobotAction.TurnLeft();
	}
	else if (blockedCommand == Command::requestTurnRight)
	{
		quadrupedRobotAction.TurnRight();
	}
	else if (blockedCommand == Command::requestActiveMode)
	{
		quadrupedRobotAction.ActiveMode();
	}
	else if (blockedCommand == Command::requestSleepMode)
	{
		quadrupedRobotAction.SleepMode();
	}
	else if (blockedCommand == Command::requestSwitchMode)
	{
		quadrupedRobotAction.SwitchMode();
	}
	else if (blockedCommand == Command::requestInstallState)
	{
		SetRobotBootState(QuadrupedRobot::State::Install);
		quadrupedRobotAction.quadrupedRobot.InstallState();
	}
	else if (blockedCommand == Command::requestCalibrateState)
	{
		SetRobotBootState(QuadrupedRobot::State::Calibrate);
		quadrupedRobotAction.quadrupedRobot.CalibrateState();
	}
	else if (blockedCommand == Command::requestBootState)
	{
		SetRobotBootState(QuadrupedRobot::State::Boot);
		quadrupedRobotAction.quadrupedRobot.BootState();
	}
	else if (blockedCommand == Command::requestCalibrateVerify)
	{
		quadrupedRobotAction.quadrupedRobot.CalibrateVerify();
	}
	else if (blockedCommand == Command::requestMoveBody)
	{
		SetRobotBootState(QuadrupedRobot::State::Boot);
		float x = moveBodyParameters[0] - 64;
		float y = moveBodyParameters[1] - 64;
		float z = moveBodyParameters[2] - 64;
		quadrupedRobotAction.MoveBody(x, y, z);
	}
	else if (blockedCommand == Command::requestRotateBody)
	{
		SetRobotBootState(QuadrupedRobot::State::Boot);
		float x = rotateBodyParameters[0] - 64;
		float y = rotateBodyParameters[1] - 64;
		float angle = sqrt(pow(x, 2) + pow(y, 2));
		quadrupedRobotAction.RotateBody(x, y, 0, angle);
	}

	this->blockedCommand = 0;
	commandState = ExecuteState::ExecuteDone;
}

void Communication::UpdateDynamicCommand()
{
	byte dynamicCommand = this->dynamicCommand;
	if (dynamicCommand == 0)
		return;

	lastBlockedCommandTime = 0;

	if (dynamicCommand == Command::requestMoveBodyTo)
	{
		SetRobotBootState(QuadrupedRobot::State::Boot);
		float x = moveBodyParameters[0] - 64;
		float y = moveBodyParameters[1] - 64;
		float z = moveBodyParameters[2] - 64;
		quadrupedRobotAction.MoveBody(x, y, z);
	}
	else if (dynamicCommand == Command::requestRotateBodyTo)
	{
		SetRobotBootState(QuadrupedRobot::State::Boot);
		float x = rotateBodyParameters[0] - 64;
		float y = rotateBodyParameters[1] - 64;
		float angle = sqrt(pow(x, 2) + pow(y, 2));
		quadrupedRobotAction.RotateBody(x, y, 0, angle);
	}
}

void Communication::UpdateAutoSleep()
{
	if (lastBlockedCommandTime != 0)
	{
		if (millis() - lastBlockedCommandTime > autoSleepOvertime)
		{
			if (quadrupedRobotAction.quadrupedRobot.state == QuadrupedRobot::State::Action)
				quadrupedRobotAction.SleepMode();
			lastBlockedCommandTime = 0;
		}
	}
}

void Communication::CheckBlockedCommand()
{
	if (commandState != ExecuteState::ExecuteDone)
		return;

	byte outData[outDataSize];
	byte outDataCounter = 0;

	outData[outDataCounter++] = Command::transStart;
	outData[outDataCounter++] = Command::commandDone;
	outData[outDataCounter++] = Command::transEnd;

	if (commandSource == CommandSource::FromSerial)
		Serial.write(outData, outDataCounter);
	else if (commandSource == CommandSource::FromESP8266)
		esp8266.send(esp8266ClientID, outData, outDataCounter);

	commandState = ExecuteState::ExecuteNone;
}

void Communication::SetRobotBootState(QuadrupedRobot::State state)
{
	byte stateByte = 0;

	if (state == QuadrupedRobot::State::Install)
		stateByte = 0;
	else if (state == QuadrupedRobot::State::Calibrate)
		stateByte = 1;
	else if (state == QuadrupedRobot::State::Boot)
		stateByte = 2;

	if (EEPROM.read(EepromAddress::robotState) != stateByte)
		EEPROM.write(EepromAddress::robotState, stateByte);
}

QuadrupedRobot::State Communication::GetRobotBootState()
{
	byte stateByte = EEPROM.read(EepromAddress::robotState);
	QuadrupedRobot::State state;

	if (stateByte == 0)
		state = QuadrupedRobot::State::Install;
	else if (stateByte == 1)
		state = QuadrupedRobot::State::Calibrate;
	else if (stateByte == 2)
		state = QuadrupedRobot::State::Boot;

	return state;
}

void UpdateService()
{
	sei();

	if (communication != NULL) {
		communication->quadrupedRobotAction.quadrupedRobot.UpdateAction();
		communication->UpdateCommunication();
	}
}

#endif
