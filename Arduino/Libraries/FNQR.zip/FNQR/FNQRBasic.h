﻿/*
 * File				Basic classes for Freenove Quadruped Robot
 * Author			Ethan Pan @ Freenove (support@freenove.com)
 * Date				2017/4/24
 * Copyright	Copyright © Freenove (http://www.freenove.com)
 * License		Creative Commons Attribution ShareAlike 3.0
 *						(http://creativecommons.org/licenses/by-sa/3.0/legalcode)
 * -----------------------------------------------------------------------------------------------*/

#pragma once
#if defined(__AVR_ATmega2560__)

#include <Arduino.h>
#include <Servo.h>
#include <EEPROM.h>
#include <FlexiTimer2.h>

class QuadrupedRobotShape
{
public:
	static const float a = 35;
	static const float b = 35;
	static const float c = 15.75;
	static const float d = 22.75;
	static const float e = 55;
	static const float f = 70;
};

class EepromAddress
{
public:
	static const float robotState = 0;
	
	static const float servo22 = 10;
	static const float servo23 = 12;
	static const float servo24 = 14;
	static const float servo25 = 16;
	static const float servo26 = 18;
	static const float servo27 = 20;
	static const float servo39 = 22;
	static const float servo38 = 24;
	static const float servo37 = 26;
	static const float servo36 = 28;
	static const float servo35 = 30;
	static const float servo34 = 32;
};

class Point
{
public:
	Point();
	Point(float x, float y, float z);

	static float GetDistance(Point point1, Point point2);

	volatile float x, y, z;
};

class QuadrupedRobotLegsPoints
{
public:
	QuadrupedRobotLegsPoints();
	QuadrupedRobotLegsPoints(Point leg1, Point leg2, Point leg3, Point leg4);

	Point leg1, leg2, leg3, leg4;
};

class QuadrupedRobotJoint
{
public:
	QuadrupedRobotJoint();
	void Set(int servoPin, float jointZero, bool jointDir, float jointMinAngle, float jointMaxAngle, int offsetAddress);

	void SetOffset(float offset);
	void SetOffsetEnableState(bool state);

	void RotateToDirectly(float jointAngle);

	float GetJointAngle(float servoAngle);

	bool CheckJointAngle(float jointAngle);

	volatile float jointAngleNow;
	volatile float servoAngleNow;

private:
	Servo servo;
	int servoPin;
	float jointZero;
	bool jointDir;
	float jointMinAngle;
	float jointMaxAngle;
	int offsetAddress;
	volatile float offset = 0;
	volatile bool isOffsetEnable = true;
	volatile bool isFirstRotate = true;
	const int firstRotateDelay = 50;
};

class QuadrupedRobotLeg
{
public:
	QuadrupedRobotLeg();
	void Set(float xOrigin, float yOrigin);

	void SetOffsetEnableState(bool state);

	void CalculatePoint(float alpha, float beta, float gamma, volatile float &x, volatile float &y, volatile float &z);
	void CalculatePoint(float alpha, float beta, float gamma, Point &point);
	void CalculateAngle(float x, float y, float z, float &alpha, float &beta, float &gamma);
	void CalculateAngle(Point point, float &alpha, float &beta, float &gamma);

	bool CheckPoint(Point point);
	bool CheckAngle(float alpha, float beta, float gamma);

	void MoveTo(Point point);
	void MoveToRelatively(Point point);
	void WaitUntilFree();

	void MoveToDirectly(Point point);
	void MoveToDirectlyRelatively(Point point);

	void RotateToDirectly(float alpha, float beta, float gamma);

	void ServosRotateTo(float degreeA, float degreeB, float degreeC);

	QuadrupedRobotJoint jointA, jointB, jointC;
	Point pointNow, pointGoal;

	static const float defaultStepDistance = 2;
	volatile float stepDistance = defaultStepDistance;

	volatile bool isBusy = false;

private:
	float xOrigin, yOrigin;
	volatile bool isFirstMove = true;
};

class QuadrupedRobot
{
public:
	QuadrupedRobot();
	void Start();

	enum State { Install, Calibrate, Boot, Action };
	State state = State::Boot;

	void InstallState();
	void CalibrateState();
	void CalibrateServos();
	void CalibrateVerify();
	void BootState();

	void MoveTo(QuadrupedRobotLegsPoints points);
	void MoveTo(QuadrupedRobotLegsPoints points, float speed);
	void MoveToRelatively(Point point);
	void MoveToRelatively(Point point, float speed);
	void WaitUntilFree();

	void SetSpeed(float speed);
	void SetSpeed(float speed1, float speed2, float speed3, float speed4);

	void GetPointsNow(QuadrupedRobotLegsPoints &points);

	void UpdateAction();

	QuadrupedRobotLeg leg1, leg2, leg3, leg4;

	QuadrupedRobotLegsPoints calibrateStatePoints = QuadrupedRobotLegsPoints(
		Point(-80, 125, 35),
		Point(-80, -125, 35),
		Point(80, 125, 35),
		Point(80, -125, 35));
	QuadrupedRobotLegsPoints calibratePoints = QuadrupedRobotLegsPoints(
		Point(-80, 125, 0),
		Point(-80, -125, 0),
		Point(80, 125, 0),
		Point(80, -125, 0));
	QuadrupedRobotLegsPoints bootPoints = QuadrupedRobotLegsPoints(
		Point(-90, 90, 0),
		Point(-90, -90, 0),
		Point(90, 90, 0),
		Point(90, -90, 0));

private:
	void CalibrateLeg(QuadrupedRobotLeg &leg, Point calibratePoint);

	void UpdateLegAction(QuadrupedRobotLeg &leg);

	void MoveToDirectly(QuadrupedRobotLegsPoints points);

	void SetOffsetEnableState(bool state);

	const float minDistance = 0.1;
};

class QuadrupedRobotAction
{
public:
	QuadrupedRobotAction();
	void Start();

	void ActiveMode();
	void SleepMode();
	void SwitchMode();

	void CrawlForward();
	void CrawlBackward();

	void TurnLeft();
	void TurnRight();

	void MoveBody(float x, float y, float z);
	void RotateBody(float x, float y, float z, float angle);

	void FeetSquareState();

	QuadrupedRobot quadrupedRobot;

private:
	void ActionState();

	enum Mode { Active, Sleep };
	enum FeetState { FeetSquare, Feet12Long, Feet34Long, FeetMove, FeetRotate };

	Mode mode = Mode::Sleep;
	FeetState feetState = FeetState::FeetSquare;

	const float speedMoveBody = 1;
	const float speedRotateBody = 1;

	void GetRotatePoints(QuadrupedRobotLegsPoints &points, float x, float y, float z, float angle);
	void GetRotatePoint(Point &point, float x, float y, float z, float angle);

	const float cAx = 15;
	const float cAy = 15;
	const float cAz = 25;

	const float speed1 = 10;
	const float speed2 = speed1 * (cAy / (7 * cAy + 2 * cAz));

	void LegStepTo(QuadrupedRobotLeg &leg, Point point, float speed);
	void LegStepToRelatively(QuadrupedRobotLeg &leg, Point point, float speed);
	void LegsMoveTo(QuadrupedRobotLegsPoints points);
	void LegsMoveTo(QuadrupedRobotLegsPoints points, float speed);
	void LegsMoveToRelatively(Point point, float speed);
	void FirstStepForward();
	void FirstStepBackward();

	const float tAl = 15;

	const float speed3 = 10;
	const float speed4 = speed3 / 5;

	const int activeStateAz = 15;

	const float turnAngle = 22.5;

	void Turn(float degree);
	void LegMoveToRelatively(QuadrupedRobotLeg &leg, Point point, float speed);
	void GetTurnPoints(QuadrupedRobotLegsPoints &points, float angle);
	void GetTurnPoint(Point &point, float angle);
	void GetMovePoints(QuadrupedRobotLegsPoints &points, Point point);
	void GetMovePoint(Point &point, Point direction);

	const float fAl = 15;
};

#endif
